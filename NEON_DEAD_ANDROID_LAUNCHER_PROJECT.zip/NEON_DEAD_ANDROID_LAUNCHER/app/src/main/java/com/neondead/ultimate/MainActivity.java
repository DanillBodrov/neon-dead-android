package com.neondead.ultimate;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    // Replace this with the HTTPS URL where you host update.json.
    private static final String UPDATE_MANIFEST_URL = "https://YOUR-DOMAIN.example/neon-dead/update.json";
    private static final String APP_VERSION = "2.0.0";
    private TextView updateStatus;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(7,10,17));
        getWindow().setNavigationBarColor(Color.rgb(7,10,17));
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(buildUi());
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(26), dp(36), dp(26), dp(30));
        root.setBackgroundColor(Color.rgb(7,10,17));
        scroll.addView(root);

        TextView eyebrow = text("SURVIVE THE OUTBREAK", 12, Color.rgb(53,246,223), true);
        eyebrow.setGravity(Gravity.CENTER);
        root.addView(eyebrow, matchWrap());

        TextView title = text("NEON DEAD", 38, Color.rgb(237,246,255), true);
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());
        TextView subtitle = text("ULTIMATE", 22, Color.rgb(192,255,89), true);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle, matchWrap());

        TextView version = text("АПОКАЛИПСИС 2.0  •  Версия " + APP_VERSION, 14, Color.rgb(146,162,184), true);
        version.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams vp = matchWrap(); vp.topMargin = dp(14); vp.bottomMargin = dp(30);
        root.addView(version, vp);

        Button play = button("▶  ИГРАТЬ");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(58));
        bp.bottomMargin = dp(12);
        root.addView(play, bp);
        play.setOnClickListener(v -> startActivity(new Intent(this, GameActivity.class)));

        Button check = button("ПРОВЕРИТЬ ОБНОВЛЕНИЯ");
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, dp(50));
        cp.bottomMargin = dp(14);
        root.addView(check, cp);
        updateStatus = text("Игра работает офлайн. Проверка обновлений требует интернета.", 13, Color.rgb(146,162,184), false);
        updateStatus.setGravity(Gravity.CENTER);
        root.addView(updateStatus, matchWrap());
        check.setOnClickListener(v -> checkUpdate());

        TextView foot = text("Игра встроена в приложение и запускается без браузера.", 12, Color.rgb(100,120,142), false);
        foot.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = matchWrap(); fp.topMargin = dp(28);
        root.addView(foot, fp);
        return scroll;
    }

    private void checkUpdate() {
        updateStatus.setText("Проверяю наличие обновлений…");
        new Thread(() -> {
            HttpURLConnection c = null;
            try {
                if (UPDATE_MANIFEST_URL.contains("YOUR-DOMAIN")) throw new Exception("Сначала укажи ссылку на свой update.json в MainActivity.java");
                c = (HttpURLConnection) new URL(UPDATE_MANIFEST_URL).openConnection();
                c.setConnectTimeout(6000); c.setReadTimeout(6000); c.setRequestMethod("GET");
                int status = c.getResponseCode();
                if (status < 200 || status >= 300) throw new Exception("Сервер ответил HTTP " + status);
                BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
                StringBuilder body = new StringBuilder(); String line;
                while ((line = r.readLine()) != null) body.append(line);
                r.close();
                JSONObject json = new JSONObject(body.toString());
                String latest = json.optString("version", APP_VERSION);
                String apkUrl = json.optString("apkUrl", "");
                String notes = json.optString("notes", "Исправления и улучшения.");
                runOnUiThread(() -> {
                    if (isNewerVersion(latest, APP_VERSION) && !apkUrl.isEmpty()) {
                        updateStatus.setText("Доступна версия " + latest);
                        new AlertDialog.Builder(this).setTitle("Доступно обновление " + latest)
                            .setMessage(notes + "\n\nAndroid попросит подтвердить установку новой версии.")
                            .setNegativeButton("Позже", (d,w) -> {})
                            .setPositiveButton("Скачать", (d,w) -> {
                                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(apkUrl))); }
                                catch (Exception e) { updateStatus.setText("Не удалось открыть ссылку на APK."); }
                            }).show();
                    } else {
                        updateStatus.setText("У тебя актуальная версия " + APP_VERSION + ".");
                    }
                });
            } catch (Exception e) {
                String msg = e.getMessage() == null ? "Не удалось проверить обновления." : e.getMessage();
                runOnUiThread(() -> updateStatus.setText(msg));
            } finally { if (c != null) c.disconnect(); }
        }).start();
    }

    private boolean isNewerVersion(String remote, String local) {
        try {
            String[] a = remote.split("\\\\.");
            String[] b = local.split("\\\\.");
            int n = Math.max(a.length, b.length);
            for (int i = 0; i < n; i++) {
                int x = i < a.length ? Integer.parseInt(a[i].replaceAll("[^0-9].*$", "")) : 0;
                int y = i < b.length ? Integer.parseInt(b[i].replaceAll("[^0-9].*$", "")) : 0;
                if (x != y) return x > y;
            }
        } catch (Exception ignored) {}
        return false;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(Color.rgb(7,10,17)); b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(53,246,223)));
        return b;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }
    private int dp(int x) { return (int)(x * getResources().getDisplayMetrics().density + 0.5f); }
}
